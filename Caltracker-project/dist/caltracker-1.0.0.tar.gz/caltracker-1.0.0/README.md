# Caltracker

Caltracker is a command-line calorie tracking application.

It lets you:

- Add meal entries with calories, category, and notes  
- View a daily summary and total calories  
- Set a daily calorie goal  
- List and delete entries  
